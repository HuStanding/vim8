9f8c26be23e2335e20f7198a4c9d29bd24ed918f
----------------------------------------

- No longer map CamelCaseMotion to `<leader>w/e/b/ge` by default.
  Requires a call to `camelcasemotion#CreateMotionMappings` to bind the default mappings.
